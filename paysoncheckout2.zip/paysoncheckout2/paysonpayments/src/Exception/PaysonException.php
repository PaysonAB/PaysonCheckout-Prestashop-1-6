<?php

namespace Payson\Payments\Exception;

/**
 * Class PaysonException
 * @package Payson\Payments\Exception
 */
class PaysonException extends \Exception
{
    
}
